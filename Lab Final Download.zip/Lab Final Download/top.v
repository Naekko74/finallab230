module top
#(
    parameter DIVIDE_BY = 17 // Use this when passing in to your clock div!
    // The test bench will set it appropriately for testing
)
(
    input [7:0] sw, // A and B
    input clk, // 100 MHz board clock
    input btnC, // Reset
    output [3:0] an, // 7seg anodes
    output [6:0] seg // 7seg segments
);

    // Instantiate the clock divider...
    // ... wire it up to the scanner
    // ... wire the scanner to the decoder
    
    wire clockWire;
    wire [3:0]plus;
    wire [3:0]minus;
    
    clock_div #(.DIVIDE_BY(DIVIDE_BY)) p1(
    .clk(clk),
    .rst(btnC),
    .div_clock(clockWire)
    );
    
    seven_seg_scanner p2(
    .div_clock(clockWire),
    .rst(btnC),
    .anode(an)
    );

    // Wire up the math block into the decoder

    seven_seg_decoder p3(
    .A(sw[3:0]),
    .B(sw[7:4]),
    .AplusB(plus),
    .AminusB(minus),
    .anode(an),
    .segs(seg)
    );

    math_block p4(
    .A(sw[3:0]),
    .B(sw[7:4]),
    .AplusB(plus),
    .AminusB(minus)
    );
    
    // Do not forget to wire up resets!!

endmodule