module full_adder(
    input A, B, Cin,
    output Y, Cout
    );
    
    //assign Y = A ^ B ^ Cin;
    //assign Cout = A&B | B&Cin | A&Cin;
    
    wire [4:0]w;
    
    xor x0(w[0], A, B);
    xor x1(Y, w[0], Cin);
    
    and a0(w[1], A, B);
    and a1(w[2], B, Cin);
    and a2(w[3], A, Cin);
    
    or o0(w[4], w[1], w[2]);
    or o1(Cout, w[3], w[4]);
    
endmodule
