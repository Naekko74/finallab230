module dff(
    input D, rst, clk,
    output reg Q,
    output notQ
    );
    
    assign notQ = ~Q;
    
    always @(posedge clk, posedge rst) begin
        if (rst)
            Q <= 0;
        else
            Q <= D;
       
    end
endmodule
