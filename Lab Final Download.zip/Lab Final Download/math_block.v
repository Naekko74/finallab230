module math_block(
    input [3:0] A,
    input [3:0] B,
    output [3:0] AplusB,
    output [3:0] AminusB
);

    //AplusB

    wire [3:0]plusCarry;

    full_adder pb0(
    .A(A[0]),
    .B(B[0]),
    .Cin(1'b0),
    .Y(AplusB[0]),
    .Cout(plusCarry[0])
    );

    full_adder pb1(
    .A(A[1]),
    .B(B[1]),
    .Cin(plusCarry[0]),
    .Y(AplusB[1]),
    .Cout(plusCarry[1])
    );
    
    full_adder pb2(
    .A(A[2]),
    .B(B[2]),
    .Cin(plusCarry[1]),
    .Y(AplusB[2]),
    .Cout(plusCarry[2])
    );
    
    full_adder pb3(
    .A(A[3]),
    .B(B[3]),
    .Cin(plusCarry[2]),
    .Y(AplusB[3]),
    .Cout(plusCarry[3])
    );
    
    //AminusB
    
    wire [3:0] twosCompB;
    wire [3:0] minusCarry;
    
    twos_comp b(
    .B(B),
    .twosCompB(twosCompB)
    );
    
    full_adder mb0(
    .A(A[0]),
    .B(twosCompB[0]),
    .Cin(1'b0),
    .Y(AminusB[0]),
    .Cout(minusCarry[0])
    );

    full_adder mb1(
    .A(A[1]),
    .B(twosCompB[1]),
    .Cin(minusCarry[0]),
    .Y(AminusB[1]),
    .Cout(minusCarry[1])
    );
    
    full_adder mb2(
    .A(A[2]),
    .B(twosCompB[2]),
    .Cin(minusCarry[1]),
    .Y(AminusB[2]),
    .Cout(minusCarry[2])
    );
    
    full_adder mb3(
    .A(A[3]),
    .B(twosCompB[3]),
    .Cin(minusCarry[2]),
    .Y(AminusB[3]),
    .Cout(minusCarry[3])
    );
    
endmodule