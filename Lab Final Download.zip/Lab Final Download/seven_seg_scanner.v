module seven_seg_scanner(
    input div_clock,
    input rst,
    output [3:0] anode
);

    wire [3:0]next;
    wire [3:0]state;
    
    assign anode = ~state;

    assign next[0] = state[3];
    assign next[1] = state[0];
    assign next[2] = state[1];
    assign next[3] = state[2];
    
    dff_dflt A(
    .dflt(1'b1),
    .D(next[0]),
    .rst(rst),
    .clk(div_clock),
    .Q(state[0])
    );
    
    dff_dflt B(
    .dflt(1'b0),
    .D(next[1]),
    .rst(rst),
    .clk(div_clock),
    .Q(state[1])
    );
    
    dff_dflt C(
    .dflt(1'b0),
    .D(next[2]),
    .rst(rst),
    .clk(div_clock),
    .Q(state[2])
    );
    
    dff_dflt D(
    .dflt(1'b0),
    .D(next[3]),
    .rst(rst),
    .clk(div_clock),
    .Q(state[3])
    );

endmodule