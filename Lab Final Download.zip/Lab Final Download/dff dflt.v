module dff_dflt(
    input D, rst, clk, dflt,
    output reg Q
    );

    initial begin
        Q <= dflt;
    end
    
    always @(posedge clk, posedge rst) begin
        if (rst)
            Q <= dflt;
        else
            Q <= D;
        
    end
endmodule