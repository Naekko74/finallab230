module twos_comp(
    input [3:0]B,
    output [4:0]twosCompB
    );
    
    wire [3:0] carry;
    
    full_adder b0(
    .A(1'b1),
    .B(~B[0]),
    .Cin(1'b0),
    .Y(twosCompB[0]),
    .Cout(carry[0])
    );
    
    full_adder b1(
    .A(1'b0),
    .B(~B[1]),
    .Cin(carry[0]),
    .Y(twosCompB[1]),
    .Cout(carry[1])
    );
    
    full_adder b2(
    .A(1'b0),
    .B(~B[2]),
    .Cin(carry[1]),
    .Y(twosCompB[2]),
    .Cout(carry[2])
    );
    
    full_adder b3(
    .A(1'b0),
    .B(~B[3]),
    .Cin(carry[2]),
    .Y(twosCompB[3])
    );
    
    
    
endmodule
