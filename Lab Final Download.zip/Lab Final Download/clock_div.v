module clock_div
#(
    parameter DIVIDE_BY = 17
)
(
    input clk,
    input rst,
    output div_clock
);

    wire [DIVIDE_BY-1:1]w;
    wire [DIVIDE_BY-1:0]d;

    assign d[0] = clk;
    assign div_clock = d[DIVIDE_BY-1];
    
    genvar n;  
    
    generate
        for(n=1; n<=DIVIDE_BY-1; n=n+1)begin
            dff ff(
            .D(w[n]),
            .rst(rst),
            .clk(d[n-1]),
            .Q(d[n]),
            .notQ(w[n])
            );
        end    
    endgenerate
    
endmodule